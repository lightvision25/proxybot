# Proxy-bot
Discord bot that can scrape proxies and send them to you
Feel free to report any issues
# Start-up
1. Install requirements by: pip install -r requirements.txt
2. Open main.py with text editor
3. In last line replace TOKEN with your discord bot token
4. Save and run main.py
# Commands
There is only one comamnd that sends you proxies
-proxy
# Invite bot
I applied it to my bot that you can invite in that link
https://discord.com/oauth2/authorize?client_id=807173971459309649&permissions=8&redirect_uri=https%3A%2F%2Ftems-py.github.io%2Fbotshop%2Fcmds_list&scope=bot
